# GBT Fullstack

Deployable fullstack dApp for GoldBarTether (GBT)